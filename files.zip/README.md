# Sistema d'avaluació CMAS · Futbol Sala

Dashboard d'avaluació de la qualitat del canvi de direcció (COD) i factors de risc de lesió, basat en el **Cutting Movement Assessment Score (CMAS)** de Dos'Santos et al. (2021), adaptat al context del futbol sala.

## Funcionalitats

- **Avaluació individual** dels 9 ítems del CMAS amb càlcul automàtic de la puntuació i categoria de risc (BAIX / MODERAT / ALT)
- **Perfil individual** amb radar gràfic, heatmap d'ítems i resum executiu del jugador
- **Pla d'intervenció personalitzat** amb recomanacions específiques per cada ítem en risc i cronograma de 7 setmanes
- **Dades agregades de l'equip** amb estadístics descriptius, distribució de risc i comparatives entre categories i costats
- **Protocol de presa de dades** i fonament científic integrats

## Ús

Obre `index.html` en qualsevol navegador modern. No requereix instal·lació ni dependències.

## Context

Eina desenvolupada en el marc d'un Treball Final de Grau (TFG) de Ciències de l'Activitat Física i l'Esport (INEFC Barcelona) en col·laboració amb el Performance Department del FC Barcelona Futbol Sala.

## Referències

Dos'Santos, T., McBurnie, A., Donelon, T., Thomas, C., Comfort, P., & Jones, P. A. (2021). The Cutting Movement Assessment Score (CMAS) qualitative screening tool: Application to mitigate anterior cruciate ligament injury risk. *Biomechanics*, 1(1), 83–101.

## Llicència

Ús intern. Reservats tots els drets.
